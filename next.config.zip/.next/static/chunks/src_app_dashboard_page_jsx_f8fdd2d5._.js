(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_b4e4597f._.js",
  "static/chunks/node_modules_next_4c048db8._.js",
  "static/chunks/node_modules_@react-google-maps_api_dist_esm_8814a7d0.js",
  "static/chunks/node_modules_react-icons_fa_index_mjs_0459ff00._.js",
  "static/chunks/node_modules_react-icons_md_index_mjs_65e576c2._.js",
  "static/chunks/node_modules_react-icons_lib_844c6c50._.js",
  "static/chunks/node_modules_axios_lib_99e19c7d._.js",
  "static/chunks/node_modules_micromark-core-commonmark_dev_lib_fc41dd51._.js",
  "static/chunks/node_modules_recharts_es6_util_913a9c4e._.js",
  "static/chunks/node_modules_recharts_es6_state_86582cda._.js",
  "static/chunks/node_modules_recharts_es6_component_aabfc5e3._.js",
  "static/chunks/node_modules_recharts_es6_cartesian_ce0acfcf._.js",
  "static/chunks/node_modules_recharts_es6_5e2af92c._.js",
  "static/chunks/node_modules_cd0ea0a5._.js"
],
    source: "dynamic"
});
