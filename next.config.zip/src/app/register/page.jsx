
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import HeaderContext from "@/components/contact/HeaderContext";
import Form from "@/components/login/Form";
import Register from "../../components/login/RegisterForm";

const Login = () => {
  return (
    <>
        <HeaderContext />
        <Header />
        <Register />
        <Footer />
    </>
)}
export default Login;